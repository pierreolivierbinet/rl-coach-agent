import os
import sys
import os
import sys

# Ensure root directory is in path to resolve 'src' module
current_dir = os.path.dirname(os.path.abspath(__file__))
root_dir = os.path.abspath(os.path.join(current_dir, "../../.."))
if root_dir not in sys.path:
    sys.path.insert(0, root_dir)

import psycopg2
from dotenv import load_dotenv
import reflex as rx

from src.agents.coach_logic import get_coach_response

load_dotenv()

DB_NAME = os.getenv("DB_NAME", "rl_coach_db")
DB_USER = os.getenv("DB_USER", "coach_admin")
DB_PASSWORD = os.getenv("DB_PASSWORD", "development_password")
DB_HOST = os.getenv("DB_HOST", "localhost")
DB_PORT = os.getenv("DB_PORT", "5432")

def get_db_connection():
    return psycopg2.connect(
        dbname=DB_NAME,
        user=DB_USER,
        password=DB_PASSWORD,
        host=DB_HOST,
        port=DB_PORT
    )


class State(rx.State):
    """The app state."""
    show_results: bool = False
    mode: str = "3v3"
    scope: str = "Match"
    coach_query: str = ""
    
    # DB Replay state
    replays: list[dict[str, str]] = []
    selected_replay_id: str = ""
    
    # AI state
    is_loading: bool = False
    ai_response: str = ""
    
    # Lobby selection
    lobby_players: list[str] = []
    selected_player: str = ""

    async def handle_analyze(self):
        """Simulate starting analysis."""
        if not self.selected_replay_id:
            self.show_results = True
            self.ai_response = "**Error:** Please select a replay from the sidebar first."
            yield
            return

        self.show_results = True
        self.is_loading = True
        self.ai_response = ""
        yield
        
        # 1. DB Fetch Context
        if not self.selected_player:
            self.ai_response = "**Error:** Please select a Focus Player from the lobby."
            self.is_loading = False
            yield
            return
            
        conn = get_db_connection()
        user_stats = {}
        try:
            with conn.cursor() as cur:
                cur.execute(
                    "SELECT * FROM player_stats WHERE ballchasing_id = %s AND player_name = %s", 
                    (self.selected_replay_id, self.selected_player)
                )
                result = cur.fetchone()
                if result:
                    colnames = [desc[0] for desc in cur.description]
                    user_stats = dict(zip(colnames, result))
        except Exception as e:
            pass
        finally:
            conn.close()

        # 2. AI Fetch
        if not user_stats:
            self.ai_response = "**Error:** Could not connect to the database to find this replay."
        else:
            self.ai_response = get_coach_response(self.coach_query, user_stats, self.mode)
            
        self.is_loading = False
        yield
        
    def set_mode(self, mode: str):
        self.mode = mode
        self.fetch_replays_from_db()
        
    def set_scope(self, scope: str):
        self.scope = scope
        
    def select_replay(self, replay_id: str):
        self.selected_replay_id = replay_id
        self.fetch_lobby_players()
        
    def set_selected_player(self, player_name: str):
        self.selected_player = player_name
        
    def fetch_lobby_players(self):
        """Fetch all unique player names for the currently selected replay."""
        self.lobby_players = []
        self.selected_player = ""
        
        if not self.selected_replay_id:
            return
            
        try:
            conn = get_db_connection()
            with conn.cursor() as cur:
                cur.execute(
                    "SELECT player_name FROM player_stats WHERE ballchasing_id = %s ORDER BY team_color, player_name", 
                    (self.selected_replay_id,)
                )
                results = cur.fetchall()
                # Deduplicate and clean, though schema should enforce uniqueness now
                players = [row[0] for row in results if row[0]]
                self.lobby_players = list(dict.fromkeys(players))
                
                if self.lobby_players:
                    # Attempt to default to the primary player profile if they are in the lobby
                    primary_name = os.getenv("PLAYER_NAME", "")
                    if primary_name in self.lobby_players:
                        self.selected_player = primary_name
                    else:
                        self.selected_player = self.lobby_players[0]
            conn.close()
        except Exception as e:
            print(f"Error fetching lobby players: {e}")
            
    def fetch_replays_from_db(self):
        """Fetch matches based on selected game mode."""
        self.replays = []
        playlist_filter = ""
        
        if self.mode == "2v2":
            playlist_filter = "AND playlist_id IN ('ranked-doubles', 'private-doubles')"
        elif self.mode == "3v3":
            playlist_filter = "AND playlist_id IN ('ranked-standard', 'ranked-solo-standard', 'private-standard')"
            
        query = f"""
            SELECT DISTINCT ON (created_at, ballchasing_id) 
                ballchasing_id, match_duration, created_at, playlist_id 
            FROM player_stats 
            WHERE 1=1 {playlist_filter}
            ORDER BY created_at DESC 
            LIMIT 10;
        """
        
        try:
            conn = get_db_connection()
            with conn.cursor() as cur:
                cur.execute(query)
                results = cur.fetchall()
                for row in results:
                    # ballchasing_id prefix to differentiate identical times visually if needed
                    bc_uid = str(row[0]).split("-")[0]
                    self.replays.append({
                        "id": row[0],
                        "duration": str(row[1]),
                        "date": str(row[2].strftime("%Y-%m-%d %H:%M")),
                        "mode": self.mode,
                        "display_id": f"[{bc_uid}]"
                    })
            conn.close()
        except Exception as e:
            print(f"Error fetching DB: {e}")
            
    def on_load(self):
        """Fetch initial data when page loads."""
        self.fetch_replays_from_db()


def replay_item(replay: dict[str, str]) -> rx.Component:
    """A component to render a single replay item."""
    return rx.box(
        rx.vstack(
            rx.text(f"{replay['date']} {replay['display_id']}", size="1", weight="bold", color=rx.color("slate", 11)),
            rx.text(f"Mode: {replay['mode']} | Duration: {replay['duration']}s", size="1", color=rx.color("slate", 10)),
            rx.button(
                "Select",
                size="1",
                width="100%",
                variant=rx.cond(State.selected_replay_id == replay["id"], "solid", "outline"),
                color_scheme=rx.cond(State.selected_replay_id == replay["id"], "blue", "gray"),
                on_click=lambda: State.select_replay(replay["id"])
            ),
            spacing="1",
            align_items="start"
        ),
        padding="0.5rem",
        border=f"1px solid {rx.color('slate', 5)}",
        border_radius="md",
        width="100%",
        bg=rx.cond(State.selected_replay_id == replay["id"], rx.color("slate", 4), rx.color("slate", 2)),
    )

def sidebar() -> rx.Component:
    """The sidebar configuration component."""
    return rx.box(
        rx.vstack(
            rx.heading("Settings", size="4", weight="bold"),
            rx.divider(margin_y="4"),
            
            rx.text("Mode", size="2", weight="medium", color=rx.color("slate", 11)),
            rx.select(
                ["2v2", "3v3"],
                value=State.mode,
                on_change=State.set_mode,
                width="100%",
                variant="surface",
            ),
            
            rx.box(height="1rem"),
            
            # Dynamic Lobby Player Selection
            rx.cond(
                State.lobby_players,
                rx.vstack(
                    rx.text("Focus Player", size="2", weight="medium", color=rx.color("blue", 11)),
                    rx.select(
                        State.lobby_players,
                        value=State.selected_player,
                        on_change=State.set_selected_player,
                        width="100%",
                        variant="surface",
                        color_scheme="blue"
                    ),
                    width="100%",
                    spacing="2"
                ),
                rx.box()
            ),
            
            rx.box(height="1rem"),
            rx.divider(margin_y="2"),
            rx.text("Recent Replays", size="2", weight="medium", color=rx.color("slate", 11)),
            
            # Replays List
            rx.scroll_area(
                rx.vstack(
                    rx.cond(
                        State.replays,
                        rx.foreach(State.replays, replay_item),
                        rx.text("No replays found matching this mode.", size="1", color=rx.color("slate", 9))
                    ),
                    spacing="2",
                    width="100%"
                ),
                height="300px",
                width="100%",
                type="auto",
            ),
            
            spacing="2",
            align_items="start",
            width="100%",
        ),
        width="260px",
        height="100vh",
        padding="1rem",
        bg=rx.color("slate", 2),
        border_right=f"1px solid {rx.color('slate', 5)}",
        position="fixed",
        left="0",
        top="0",
        z_index="10",
    )

def main_content() -> rx.Component:
    """The central input and analytic grid."""
    
    # Text input area
    query_input = rx.vstack(
        rx.heading("RL Coach Agent", size="8", weight="bold", align="center"),
        rx.text("Ask me about your latest game, or how you compare to the pros.", color=rx.color("slate", 11), align="center"),
        rx.box(height="1rem"),
        rx.hstack(
            rx.input(
                placeholder="E.g., What went wrong? Why are my rotations slow?",
                value=State.coach_query,
                on_change=State.setvar("coach_query"),
                size="3",
                width="100%",
                radius="large",
                variant="surface",
            ),
            rx.button(
                rx.icon("send", size=20),
                "Analyze",
                size="3",
                on_click=State.handle_analyze,
                radius="large",
                variant="solid",
                color_scheme="blue",
            ),
            width="100%",
            align_items="center",
            spacing="2",
        ),
        # When analyzing, visually compress the query input block
        width=rx.cond(State.show_results, "100%", "60%"), 
        max_width="800px",
        padding="2rem",
        transition="all 0.4s ease-in-out",
        align_items="center",
    )

    # Placeholder charts grid (visible only when showing results)
    analytic_grid = rx.cond(
        State.show_results,
        rx.vstack(
            # Loading or Response
            rx.cond(
                State.is_loading,
                rx.center(
                    rx.vstack(
                        rx.spinner(size="3"),
                        rx.text("Analyzing match data...", color=rx.color("slate", 11)),
                        align_items="center"
                    ),
                    padding="2rem",
                    width="100%",
                ),
                rx.box(
                    rx.markdown(State.ai_response),
                    bg=rx.color("slate", 3),
                    padding="2rem",
                    border_radius="md",
                    border=f"1px solid {rx.color('slate', 5)}",
                    width="100%",
                )
            ),
            
            # Additional Charts
            rx.grid(
                rx.box(
                    rx.center(rx.text("Radar Chart Placeholder", weight="bold")),
                    bg=rx.color("slate", 3),
                    padding="1rem",
                    border_radius="md",
                    border=f"1px solid {rx.color('slate', 5)}",
                    height="300px",
                ),
                rx.box(
                    rx.center(rx.text("Mechanic Bars Placeholder", weight="bold")),
                    bg=rx.color("slate", 3),
                    padding="1rem",
                    border_radius="md",
                    border=f"1px solid {rx.color('slate', 5)}",
                    height="300px",
                ),
                columns="2",
                spacing="4",
                width="100%",
                margin_top="2rem",
            ),
            width="100%",
            spacing="4"
        ),
        rx.box()
    )

    return rx.box(
        rx.vstack(
            query_input,
            analytic_grid,
            width="100%",
            height="100vh",
            align_items="center",
            justify_content=rx.cond(State.show_results, "start", "center"),
            padding_top=rx.cond(State.show_results, "4rem", "0"),
            transition="all 0.4s ease-in-out",
            padding_x="2rem",
        ),
        margin_left="260px", # Offset for fixed sidebar
        width="calc(100% - 260px)",
        bg=rx.color("slate", 1),
    )

def index() -> rx.Component:
    """The main page layout."""
    return rx.box(
        sidebar(),
        main_content(),
        background_color=rx.color("slate", 1),
        min_height="100vh",
        color=rx.color("slate", 12),
        font_family="system-ui, sans-serif",
    )

app = rx.App(
    theme=rx.theme(
        appearance="dark",
        has_background=True,
        radius="large",
        accent_color="blue", # Highlights
        gray_color="slate",  # Dark zinc/slate palette
    ),
)
app.add_page(index, title="RL Coach Agent", on_load=State.on_load)
